How to install locally :

    On linux / MacOS:
    copy the extention to the`~/.vscode/extentions/` folder then restart vscode .

    On windows :
    copy the extention to the`%USERPROFILE%\.vscode\extensions.` folder then restart vscode .

If the UI configuration for the author doesn't work:

    open the vscode setting.json and add and complete the following line:

    `"cpp-smart-comment.author": "Authorname",`

    then save and restart the vscode.
