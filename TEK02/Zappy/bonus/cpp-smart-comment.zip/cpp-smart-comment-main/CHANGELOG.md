# Change Log

All notable changes to the "cpp-smart-comment" extension will be documented in this file.

## [1.0.0]

- Initial release
- Basic comment for c/c++ functions, c++ class, class constructor/destructor and class member.
- Support for indentation
- Support for the author section and save of author configuration

## [1.0.1]

- fix: functions with only void were unable to parse
- now supports a older version of vscode
